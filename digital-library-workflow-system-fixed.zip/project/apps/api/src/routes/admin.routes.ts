import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { prisma } from "../lib/prisma";
import { ApiError } from "../utils/apiError";
import { recordAudit } from "../utils/audit";
import { configUpdateSchema, stageUpdateSchema } from "../validation";

const router = Router();

// Every route here requires SYSTEM_ADMIN — enforced server-side regardless
// of what the frontend shows.
router.use(authenticate, authorize("SYSTEM_ADMIN"));

router.get(
  "/users",
  asyncHandler(async (_req, res) => {
    const users = await prisma.user.findMany({
      include: { roles: { include: { role: true } } },
      orderBy: { createdAt: "asc" },
    });
    res.json({
      users: users.map((u) => ({
        id: u.id,
        email: u.email,
        fullName: u.fullName,
        department: u.department,
        isActive: u.isActive,
        isDemo: u.isDemo,
        roles: u.roles.map((r) => r.role.key),
      })),
    });
  })
);

router.get(
  "/stages",
  asyncHandler(async (_req, res) => {
    const stages = await prisma.workflowStage.findMany({ include: { requiredRole: true }, orderBy: { order: "asc" } });
    res.json({ stages });
  })
);

router.patch(
  "/stages/:id",
  asyncHandler(async (req, res) => {
    const body = stageUpdateSchema.parse(req.body);
    const stage = await prisma.workflowStage.findUnique({ where: { id: req.params.id } });
    if (!stage) throw new ApiError(404, "Stage not found.");
    const updated = await prisma.workflowStage.update({ where: { id: req.params.id }, data: body });
    await recordAudit({
      userId: req.user!.id,
      roleKeyAtTime: "SYSTEM_ADMIN",
      action: "WORKFLOW_STAGE_UPDATED",
      metadata: { stageKey: stage.key, changes: body },
    });
    res.json({ stage: updated });
  })
);

router.get(
  "/config",
  asyncHandler(async (_req, res) => {
    const config = await prisma.systemConfig.findMany();
    res.json({ config });
  })
);

router.patch(
  "/config/:key",
  asyncHandler(async (req, res) => {
    const { value } = configUpdateSchema.parse(req.body);
    const existing = await prisma.systemConfig.findUnique({ where: { key: req.params.key } });
    if (!existing) throw new ApiError(404, "Config key not found.");
    const updated = await prisma.systemConfig.update({ where: { key: req.params.key }, data: { value } });
    await recordAudit({
      userId: req.user!.id,
      roleKeyAtTime: "SYSTEM_ADMIN",
      action: "CONFIG_UPDATED",
      metadata: { key: req.params.key, value },
    });
    res.json({ config: updated });
  })
);

router.get(
  "/audit",
  asyncHandler(async (_req, res) => {
    const logs = await prisma.auditLog.findMany({
      include: { user: { select: { fullName: true } }, bookRequest: { select: { displayId: true } } },
      orderBy: { createdAt: "desc" },
      take: 200,
    });
    res.json({ logs });
  })
);

export default router;
