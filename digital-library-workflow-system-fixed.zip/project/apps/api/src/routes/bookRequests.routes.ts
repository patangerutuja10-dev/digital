import { Router } from "express";
import { authenticate } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { prisma } from "../lib/prisma";
import { ApiError } from "../utils/apiError";
import { recordAudit } from "../utils/audit";
import { nextDisplayId } from "../utils/requestId";
import {
  addItemSchema,
  cancelRequestSchema,
  createRequestSchema,
  decisionSchema,
  librarianVerifySchema,
  supportSchema,
} from "../validation";
import {
  addSupport,
  archiveRequest,
  buildTimeline,
  cancelRequest,
  decide,
  getOrderedStages,
  librarianVerify,
  removeSupport,
  submitRequest,
} from "../services/workflowEngine";
import { findSimilarBooks } from "../services/similarityClient";

const router = Router();

const REQUEST_INCLUDE = {
  items: true,
  requestedBy: { select: { id: true, fullName: true, email: true } },
  procurement: true,
  _count: { select: { supports: true } },
} as const;

/**
 * Returns requests relevant to the authenticated user:
 * - every request they created
 * - requests currently sitting at a stage whose requiredRole matches one of
 *   their roles (i.e. "pending action for me")
 * - SYSTEM_ADMIN sees everything
 */
router.get(
  "/",
  authenticate,
  asyncHandler(async (req, res) => {
    const user = req.user!;
    const showHistory = req.query.history === "true"; // include archived (cleared) requests

    if (user.roles.includes("SYSTEM_ADMIN")) {
      const all = await prisma.bookRequest.findMany({
        where: showHistory ? undefined : { archivedAt: null },
        include: REQUEST_INCLUDE,
        orderBy: { createdAt: "desc" },
      });
      return res.json({ results: all });
    }

    const stages = await getOrderedStages();
    const actionableStageKeys = stages
      .filter((s) => s.requiredRole && user.roles.includes(s.requiredRole.key))
      .map((s) => s.key);

    const requests = await prisma.bookRequest.findMany({
      where: {
        AND: [
          showHistory ? {} : { archivedAt: null },
          {
            OR: [
              { requestedById: user.id },
              actionableStageKeys.length ? { status: { in: actionableStageKeys } } : undefined,
              // Every request currently collecting support is visible to
              // everyone (not just the requester) — otherwise nobody else
              // could ever see it to support it. The "Support" button itself
              // still stays restricted to non-owners, per the page's own check.
              { status: "SUPPORT_COLLECTION" },
            ].filter(Boolean) as any,
          },
        ],
      },
      include: REQUEST_INCLUDE,
      orderBy: { createdAt: "desc" },
    });
    res.json({ results: requests });
  })
);

router.post(
  "/",
  authenticate,
  asyncHandler(async (req, res) => {
    const body = createRequestSchema.parse(req.body);
    const displayId = await nextDisplayId();

    const request = await prisma.bookRequest.create({
      data: {
        displayId,
        requestedById: req.user!.id,
        currentStageKey: "DRAFT",
        status: "DRAFT",
        items: { create: body.items },
      },
      include: REQUEST_INCLUDE,
    });

    await recordAudit({
      bookRequestId: request.id,
      userId: req.user!.id,
      roleKeyAtTime: req.user!.roles[0],
      action: "REQUEST_CREATED",
    });

    res.status(201).json({ request });
  })
);

router.get(
  "/:id",
  authenticate,
  asyncHandler(async (req, res) => {
    const request = await prisma.bookRequest.findUnique({
      where: { id: req.params.id },
      include: { ...REQUEST_INCLUDE, supports: { include: { user: { select: { id: true, fullName: true } } } } },
    });
    if (!request) throw new ApiError(404, "Request not found.");
    res.json({ request });
  })
);

router.post(
  "/:id/items",
  authenticate,
  asyncHandler(async (req, res) => {
    const item = addItemSchema.parse(req.body);
    const request = await prisma.bookRequest.findUnique({ where: { id: req.params.id } });
    if (!request) throw new ApiError(404, "Request not found.");
    if (request.requestedById !== req.user!.id) throw new ApiError(403, "Not your request.");
    if (!["DRAFT", "RETURNED_FOR_CORRECTION"].includes(request.status)) {
      throw new ApiError(409, "Items can only be edited while a request is in draft or returned for correction.");
    }
    const created = await prisma.requestItem.create({ data: { ...item, bookRequestId: request.id } });
    res.status(201).json({ item: created });
  })
);

router.post(
  "/:id/submit",
  authenticate,
  asyncHandler(async (req, res) => {
    const updated = await submitRequest(req.params.id, req.user!);
    res.json({ request: updated });
  })
);

router.post(
  "/:id/support",
  authenticate,
  asyncHandler(async (req, res) => {
    const { comment } = supportSchema.parse(req.body ?? {});
    const result = await addSupport(req.params.id, req.user!, comment);
    res.status(201).json(result);
  })
);

router.delete(
  "/:id/support",
  authenticate,
  asyncHandler(async (req, res) => {
    await removeSupport(req.params.id, req.user!);
    res.json({ ok: true });
  })
);

router.post(
  "/:id/cancel",
  authenticate,
  asyncHandler(async (req, res) => {
    const { reason } = cancelRequestSchema.parse(req.body);
    const updated = await cancelRequest(req.params.id, req.user!, reason);
    res.json({ request: updated });
  })
);

router.post(
  "/:id/archive",
  authenticate,
  asyncHandler(async (req, res) => {
    // Only the requester or an admin/librarian may clear a request from the
    // active panel — anyone shouldn't be able to hide someone else's request.
    const request = await prisma.bookRequest.findUnique({ where: { id: req.params.id } });
    if (!request) throw new ApiError(404, "Request not found.");
    const allowed =
      request.requestedById === req.user!.id || req.user!.roles.some((r) => ["SYSTEM_ADMIN", "LIBRARIAN"].includes(r));
    if (!allowed) throw new ApiError(403, "You don't have permission to clear this request.");
    const updated = await archiveRequest(req.params.id, req.user!);
    res.json({ request: updated });
  })
);

router.post(
  "/:id/decision",
  authenticate,
  asyncHandler(async (req, res) => {
    const { decision, comment } = decisionSchema.parse(req.body);
    const updated = await decide(req.params.id, req.user!, decision, comment);
    res.json({ request: updated });
  })
);

router.post(
  "/:id/librarian-verify",
  authenticate,
  asyncHandler(async (req, res) => {
    const { availableInLibrary, comment } = librarianVerifySchema.parse(req.body);
    const updated = await librarianVerify(req.params.id, req.user!, availableInLibrary, comment);
    res.json({ request: updated });
  })
);

router.get(
  "/:id/timeline",
  authenticate,
  asyncHandler(async (req, res) => {
    const timeline = await buildTimeline(req.params.id);
    res.json({ timeline });
  })
);

router.get(
  "/:id/audit",
  authenticate,
  asyncHandler(async (req, res) => {
    const logs = await prisma.auditLog.findMany({
      where: { bookRequestId: req.params.id },
      include: { user: { select: { fullName: true } } },
      orderBy: { createdAt: "asc" },
    });
    res.json({ logs });
  })
);

router.get(
  "/:id/similar",
  authenticate,
  asyncHandler(async (req, res) => {
    const request = await prisma.bookRequest.findUnique({
      where: { id: req.params.id },
      include: { items: true },
    });
    if (!request) throw new ApiError(404, "Request not found.");
    const firstItem = request.items[0];
    if (!firstItem) return res.json({ matches: [], method: "tfidf-cosine-similarity" });
    const matches = await findSimilarBooks(firstItem.title, firstItem.author);
    res.json({ matches, method: "tfidf-cosine-similarity" });
  })
);

export default router;
