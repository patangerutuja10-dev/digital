import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { prisma } from "../lib/prisma";
import { ApiError } from "../utils/apiError";
import { recordAudit } from "../utils/audit";
import { notifyUser } from "../utils/notify";
import { completeAfterAccession } from "../services/workflowEngine";
import { procurementCreateSchema, procurementUpdateSchema } from "../validation";

const router = Router();

function computeBalance(totalBudget?: number | null, orderAmount?: number | null) {
  if (totalBudget == null || orderAmount == null) return null;
  return Number((totalBudget - orderAmount).toFixed(2));
}

router.get(
  "/:bookRequestId",
  authenticate,
  asyncHandler(async (req, res) => {
    const record = await prisma.procurementRecord.findUnique({ where: { bookRequestId: req.params.bookRequestId } });
    if (!record) throw new ApiError(404, "No procurement record yet for this request.");
    res.json({ procurement: record });
  })
);

router.post(
  "/:bookRequestId",
  authenticate,
  authorize("PROCUREMENT_ADMIN", "SYSTEM_ADMIN"),
  asyncHandler(async (req, res) => {
    const body = procurementCreateSchema.parse(req.body);
    const request = await prisma.bookRequest.findUnique({ where: { id: req.params.bookRequestId } });
    if (!request) throw new ApiError(404, "Request not found.");
    if (request.status !== "PROCUREMENT") {
      throw new ApiError(409, "This request is not currently at the procurement stage.");
    }

    const balanceAvailable = computeBalance(body.totalBudget, body.orderAmount);

    const record = await prisma.procurementRecord.upsert({
      where: { bookRequestId: req.params.bookRequestId },
      update: {
        orderSentTo: body.orderSentTo,
        orderNumber: body.orderNumber,
        orderDate: body.orderDate ? new Date(body.orderDate) : undefined,
        totalBudget: body.totalBudget,
        orderAmount: body.orderAmount,
        balanceAvailable,
      },
      create: {
        bookRequestId: req.params.bookRequestId,
        orderSentTo: body.orderSentTo,
        orderNumber: body.orderNumber,
        orderDate: body.orderDate ? new Date(body.orderDate) : undefined,
        totalBudget: body.totalBudget,
        orderAmount: body.orderAmount,
        balanceAvailable,
      },
    });

    await recordAudit({
      bookRequestId: req.params.bookRequestId,
      userId: req.user!.id,
      roleKeyAtTime: "PROCUREMENT_ADMIN",
      action: "PROCUREMENT_ORDER_RECORDED",
      metadata: { orderNumber: body.orderNumber, orderAmount: body.orderAmount, balanceAvailable },
    });

    res.status(201).json({ procurement: record });
  })
);

router.patch(
  "/:bookRequestId",
  authenticate,
  authorize("PROCUREMENT_ADMIN", "SYSTEM_ADMIN"),
  asyncHandler(async (req, res) => {
    const body = procurementUpdateSchema.parse(req.body);
    const existing = await prisma.procurementRecord.findUnique({ where: { bookRequestId: req.params.bookRequestId } });
    if (!existing) throw new ApiError(404, "No procurement record exists yet — create one first.");

    const totalBudget = body.totalBudget ?? existing.totalBudget ?? undefined;
    const orderAmount = body.orderAmount ?? existing.orderAmount ?? undefined;
    const balanceAvailable = computeBalance(totalBudget, orderAmount);

    const updated = await prisma.procurementRecord.update({
      where: { bookRequestId: req.params.bookRequestId },
      data: {
        orderSentTo: body.orderSentTo,
        orderNumber: body.orderNumber,
        orderDate: body.orderDate ? new Date(body.orderDate) : undefined,
        totalBudget: body.totalBudget,
        orderAmount: body.orderAmount,
        balanceAvailable,
        billNumber: body.billNumber,
        billDate: body.billDate ? new Date(body.billDate) : undefined,
        billAmount: body.billAmount,
        accessionedAt: body.markAccessioned ? new Date() : undefined,
      },
    });

    await recordAudit({
      bookRequestId: req.params.bookRequestId,
      userId: req.user!.id,
      roleKeyAtTime: "PROCUREMENT_ADMIN",
      action: body.billNumber ? "PROCUREMENT_BILL_RECORDED" : "PROCUREMENT_UPDATED",
      metadata: { billNumber: body.billNumber, billAmount: body.billAmount },
    });

    if (body.markAccessioned) {
      await completeAfterAccession(req.params.bookRequestId);
      const request = await prisma.bookRequest.findUnique({ where: { id: req.params.bookRequestId } });
      if (request) {
        await notifyUser(request.requestedById, `Your request ${request.displayId} is complete — book accessioned into the library.`, request.id);
      }
    }

    res.json({ procurement: updated });
  })
);

export default router;
