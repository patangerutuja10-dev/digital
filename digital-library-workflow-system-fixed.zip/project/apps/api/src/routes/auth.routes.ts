import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import rateLimit from "express-rate-limit";
import { prisma } from "../lib/prisma";
import { env } from "../config/env";
import { asyncHandler } from "../middleware/errorHandler";
import { authenticate } from "../middleware/auth";
import { ApiError } from "../utils/apiError";
import { loginSchema } from "../validation";
import { recordAudit } from "../utils/audit";

const router = Router();

// Slow down brute-force attempts on login. Basic protection appropriate for
// a college project — not a substitute for a proper WAF in production.
const loginLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many login attempts. Please try again later." },
});

router.post(
  "/login",
  loginLimiter,
  asyncHandler(async (req, res) => {
    const { email, password } = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      include: { roles: { include: { role: true } } },
    });

    // Same generic error for "no such user" and "wrong password" so we don't
    // leak which accounts exist.
    if (!user || !user.isActive) {
      throw new ApiError(401, "Invalid email or password.");
    }
    const passwordOk = await bcrypt.compare(password, user.passwordHash);
    if (!passwordOk) {
      throw new ApiError(401, "Invalid email or password.");
    }

    const roles = user.roles.map((r) => r.role.key);
    const token = jwt.sign(
      { id: user.id, email: user.email, fullName: user.fullName, roles, department: user.department },
      env.jwtSecret,
      { expiresIn: env.jwtExpiresIn } as jwt.SignOptions
    );

    await recordAudit({ userId: user.id, roleKeyAtTime: roles[0], action: "LOGIN" });

    res.json({
      token,
      user: { id: user.id, email: user.email, fullName: user.fullName, roles, department: user.department, isDemo: user.isDemo },
    });
  })
);

router.post(
  "/logout",
  authenticate,
  asyncHandler(async (req, res) => {
    // JWTs are stateless; logout is a client-side token discard. We still log
    // it for audit visibility.
    await recordAudit({ userId: req.user!.id, roleKeyAtTime: req.user!.roles[0], action: "LOGOUT" });
    res.json({ ok: true });
  })
);

router.get(
  "/me",
  authenticate,
  asyncHandler(async (req, res) => {
    res.json({ user: req.user });
  })
);

export default router;
