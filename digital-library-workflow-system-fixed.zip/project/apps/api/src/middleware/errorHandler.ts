import { NextFunction, Request, Response } from "express";
import { ZodError } from "zod";
import { ApiError } from "../utils/apiError";
import { env } from "../config/env";

/** 404 fallback for unmatched routes. */
export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({ error: "Not found", path: req.originalUrl });
}

/**
 * Single place that turns any thrown error into a safe, consistent JSON
 * response. Never leaks stack traces or internal error messages in
 * production; validation errors are surfaced field-by-field so the frontend
 * can show useful messages.
 */
export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
) {
  if (err instanceof ZodError) {
    return res.status(400).json({
      error: "Validation failed",
      issues: err.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }

  if (err instanceof ApiError) {
    return res.status(err.status).json({ error: err.message, details: err.details });
  }

  // Unknown/unexpected error
  // eslint-disable-next-line no-console
  console.error(err);
  const message =
    env.nodeEnv === "production"
      ? "Something went wrong. Please try again."
      : err instanceof Error
      ? err.message
      : "Unknown error";
  return res.status(500).json({ error: message });
}

/** Wraps an async route handler so thrown/rejected errors reach errorHandler. */
export function asyncHandler<T extends (...args: any[]) => Promise<any>>(fn: T) {
  return (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
}
