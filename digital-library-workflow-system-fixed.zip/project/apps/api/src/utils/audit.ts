import { prisma } from "../lib/prisma";

interface AuditParams {
  bookRequestId?: string;
  userId?: string;
  roleKeyAtTime?: string;
  action: string;
  metadata?: Record<string, unknown>;
}

/**
 * Appends an immutable audit event. There is intentionally no update/delete
 * function for audit rows anywhere in this codebase, and no route exposes one.
 */
export async function recordAudit(params: AuditParams) {
  await prisma.auditLog.create({
    data: {
      bookRequestId: params.bookRequestId,
      userId: params.userId,
      roleKeyAtTime: params.roleKeyAtTime,
      action: params.action,
      metadata: params.metadata ? JSON.stringify(params.metadata) : null,
    },
  });
}
