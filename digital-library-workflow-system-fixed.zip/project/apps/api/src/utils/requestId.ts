import { prisma } from "../lib/prisma";

/**
 * Generates the next sequential display ID for the current year, e.g.
 * BR-2026-0001, BR-2026-0002, ... Sequencing is derived from a DB count
 * inside a transaction-safe read at call time; for a college-scale request
 * volume this is more than sufficient and keeps the schema simple.
 */
export async function nextDisplayId(): Promise<string> {
  const year = new Date().getFullYear();
  const prefix = `BR-${year}-`;
  const countThisYear = await prisma.bookRequest.count({
    where: { displayId: { startsWith: prefix } },
  });
  const next = (countThisYear + 1).toString().padStart(4, "0");
  return `${prefix}${next}`;
}
