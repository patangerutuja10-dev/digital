/**
 * College departments (per the guide's instruction: route HOD approval to the
 * matching department's own HOD, since every department has a different HOD).
 * Edit this list if the college adds/renames a department — nothing else in
 * the codebase hard-codes department names outside this file and the seed
 * data that uses it.
 */
export const DEPARTMENTS = [
  { key: "CIVIL", label: "Civil Engineering" },
  { key: "MECHANICAL", label: "Mechanical Engineering" },
  { key: "CSE", label: "Computer Science & Engineering" },
  { key: "AIDS", label: "Artificial Intelligence & Data Science" },
  { key: "MCA", label: "Master of Computer Applications" },
] as const;

export type DepartmentKey = (typeof DEPARTMENTS)[number]["key"];

export const DEPARTMENT_KEYS = DEPARTMENTS.map((d) => d.key);
