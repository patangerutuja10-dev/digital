export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  roles: string[]; // role keys, e.g. ["STUDENT"]
  department?: string | null;
}

// Augment Express's Request type with our authenticated user.
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}
