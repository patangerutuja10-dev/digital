import express from "express";
import cors from "cors";
import morgan from "morgan";
import { env } from "./config/env";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";

import authRoutes from "./routes/auth.routes";
import catalogueRoutes from "./routes/catalogue.routes";
import bookRequestRoutes from "./routes/bookRequests.routes";
import procurementRoutes from "./routes/procurement.routes";
import notificationRoutes from "./routes/notifications.routes";
import adminRoutes from "./routes/admin.routes";

const app = express();

app.use(cors({ origin: env.corsOrigin, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan(env.nodeEnv === "production" ? "combined" : "dev"));

app.get("/health", (_req, res) => res.json({ ok: true, service: "library-workflow-api" }));

app.use("/auth", authRoutes);
app.use("/catalogue", catalogueRoutes);
app.use("/book-requests", bookRequestRoutes);
app.use("/procurement", procurementRoutes);
app.use("/notifications", notificationRoutes);
app.use("/admin", adminRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

app.listen(env.port, () => {
  // eslint-disable-next-line no-console
  console.log(`Library workflow API listening on http://localhost:${env.port}`);
});
