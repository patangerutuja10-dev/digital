import { PrismaClient } from "@prisma/client";

// A single shared Prisma client instance (avoids exhausting DB connections
// during dev hot-reload).
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma = global.__prisma ?? new PrismaClient();

if (env_is_dev()) {
  global.__prisma = prisma;
}

function env_is_dev() {
  return process.env.NODE_ENV !== "production";
}
