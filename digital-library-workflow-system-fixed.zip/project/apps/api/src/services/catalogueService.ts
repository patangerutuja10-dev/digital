import { prisma } from "../lib/prisma";

export interface CatalogueBookDTO {
  id: string;
  title: string;
  author: string;
  publication: string | null;
  copiesOwned: number;
}

/**
 * Abstraction over "wherever the book catalogue actually lives". Today only
 * DemoCatalogueService exists, backed by this app's own database. If/when the
 * college confirms the real LMS exposes an API, implement LMSCatalogueService
 * against this same interface and swap it in `getCatalogueService()` below —
 * no caller code needs to change.
 */
export interface CatalogueService {
  search(query: string): Promise<CatalogueBookDTO[]>;
  getById(id: string): Promise<CatalogueBookDTO | null>;
  listAll(): Promise<CatalogueBookDTO[]>;
}

class DemoCatalogueService implements CatalogueService {
  async search(query: string): Promise<CatalogueBookDTO[]> {
    const q = query.trim();
    if (!q) return this.listAll();
    const rows = await prisma.catalogueBook.findMany({
      where: {
        OR: [
          { title: { contains: q } },
          { author: { contains: q } },
          { publication: { contains: q } },
        ],
      },
      take: 25,
    });
    return rows;
  }

  async getById(id: string): Promise<CatalogueBookDTO | null> {
    return prisma.catalogueBook.findUnique({ where: { id } });
  }

  async listAll(): Promise<CatalogueBookDTO[]> {
    return prisma.catalogueBook.findMany({ take: 100, orderBy: { title: "asc" } });
  }
}

// class LMSCatalogueService implements CatalogueService { ... } // future work

let instance: CatalogueService | null = null;

/** This system is NOT currently integrated with the college's real LMS. */
export function getCatalogueService(): CatalogueService {
  if (!instance) instance = new DemoCatalogueService();
  return instance;
}
