import fetch from "node-fetch";
import { env } from "../config/env";
import { getCatalogueService } from "./catalogueService";
import { ApiError } from "../utils/apiError";

export interface SimilarityMatch {
  id: string;
  title: string;
  author: string;
  publication: string | null;
  similarity: number; // 0-100
}

/**
 * Calls the separate FastAPI similarity service. This uses TF-IDF + cosine
 * similarity over title/author/publication text (see apps/ai/main.py) — a
 * real, working, explainable similarity search, not a marketing claim of
 * "AI" with keyword matching underneath. If the AI service is unreachable,
 * we fail soft (return []) with a warning rather than blocking the workflow.
 */
export async function findSimilarBooks(title: string, author: string): Promise<SimilarityMatch[]> {
  const catalogue = await getCatalogueService().listAll();
  if (catalogue.length === 0) return [];

  try {
    const res = await fetch(`${env.aiServiceUrl}/similarity`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: { title, author },
        catalogue: catalogue.map((c) => ({ id: c.id, title: c.title, author: c.author, publication: c.publication })),
      }),
      timeout: 5000,
    } as any);
    if (!res.ok) throw new ApiError(502, "AI similarity service returned an error.");
    const data = (await res.json()) as { matches: SimilarityMatch[] };
    return data.matches;
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn("[similarityClient] AI service unavailable, returning no matches:", e);
    return [];
  }
}
