import { prisma } from "../lib/prisma";
import { ApiError } from "../utils/apiError";
import { recordAudit } from "../utils/audit";
import { notifyUsersWithRole, notifyUser } from "../utils/notify";
import { AuthUser } from "../types";

/** Reads all active stages ordered by their configured `order` column. */
export async function getOrderedStages() {
  return prisma.workflowStage.findMany({
    where: { isActive: true },
    orderBy: { order: "asc" },
    include: { requiredRole: true },
  });
}

export async function getStageByKey(key: string) {
  const stage = await prisma.workflowStage.findUnique({
    where: { key },
    include: { requiredRole: true },
  });
  if (!stage) throw new ApiError(500, `Workflow misconfiguration: unknown stage "${key}".`);
  return stage;
}

/** Returns the next non-terminal stage after `currentKey` in configured order. */
async function getNextStage(currentKey: string) {
  const stages = await getOrderedStages();
  const nonTerminalMain = stages.filter((s) => !s.isTerminal && s.key !== "RETURNED_FOR_CORRECTION");
  const idx = nonTerminalMain.findIndex((s) => s.key === currentKey);
  if (idx === -1 || idx + 1 >= nonTerminalMain.length) return null;
  return nonTerminalMain[idx + 1];
}

export async function getConfigValue(key: string, fallback: string): Promise<string> {
  const row = await prisma.systemConfig.findUnique({ where: { key } });
  return row?.value ?? fallback;
}

export async function getRequiredSupportCount(): Promise<number> {
  const raw = await getConfigValue("requiredSupportCount", "10");
  const n = parseInt(raw, 10);
  return Number.isFinite(n) && n > 0 ? n : 10;
}

/**
 * DRAFT/RETURNED -> SUBMITTED -> (SUPPORT_COLLECTION if configured) -> first review stage.
 * Called by the requester. Server decides the destination stage; the client
 * cannot specify one.
 */
export async function submitRequest(bookRequestId: string, actor: AuthUser) {
  const request = await prisma.bookRequest.findUnique({ where: { id: bookRequestId }, include: { items: true } });
  if (!request) throw new ApiError(404, "Request not found.");
  if (request.requestedById !== actor.id) {
    throw new ApiError(403, "Only the requester can submit this request.");
  }
  if (!["DRAFT", "RETURNED_FOR_CORRECTION"].includes(request.status)) {
    throw new ApiError(409, `Cannot submit a request currently in status ${request.status}.`);
  }
  if (request.items.length === 0) {
    throw new ApiError(400, "Add at least one book item before submitting.");
  }

  const stages = await getOrderedStages();
  const supportStage = stages.find((s) => s.key === "SUPPORT_COLLECTION");
  const wasReturned = request.status === "RETURNED_FOR_CORRECTION";

  // If resubmitting after a return, skip support collection again (support was
  // already gathered) and go straight to the first review stage.
  const destination = wasReturned
    ? stages.find((s) => s.key === "UNDER_REVIEW")!
    : supportStage ?? stages.find((s) => s.key === "UNDER_REVIEW")!;

  const updated = await prisma.bookRequest.update({
    where: { id: bookRequestId },
    data: { status: destination.key, currentStageKey: destination.key },
  });

  await recordAudit({
    bookRequestId,
    userId: actor.id,
    roleKeyAtTime: actor.roles[0],
    action: wasReturned ? "REQUEST_RESUBMITTED" : "REQUEST_SUBMITTED",
  });

  if (destination.key === "SUPPORT_COLLECTION") {
    // No specific role to notify yet — informational only.
  } else if (destination.requiredRole) {
    await notifyUsersWithRole(
      destination.requiredRole.key,
      `${destination.requiredRole.label} review required for ${request.displayId}.`,
      bookRequestId
    );
  }

  return updated;
}

/** One authenticated account may support a request only once (DB-enforced too). */
export async function addSupport(bookRequestId: string, actor: AuthUser, comment?: string) {
  const request = await prisma.bookRequest.findUnique({ where: { id: bookRequestId } });
  if (!request) throw new ApiError(404, "Request not found.");
  if (request.status !== "SUPPORT_COLLECTION") {
    throw new ApiError(409, "This request is not currently collecting support.");
  }
  if (request.requestedById === actor.id) {
    throw new ApiError(400, "You cannot support your own request.");
  }

  try {
    await prisma.support.create({
      data: { bookRequestId, userId: actor.id, comment },
    });
  } catch (e: any) {
    if (e?.code === "P2002") {
      throw new ApiError(409, "You have already supported this request.");
    }
    throw e;
  }

  await recordAudit({
    bookRequestId,
    userId: actor.id,
    roleKeyAtTime: actor.roles[0],
    action: "SUPPORT_ADDED",
  });

  const [supportCount, requiredCount] = await Promise.all([
    prisma.support.count({ where: { bookRequestId } }),
    getRequiredSupportCount(),
  ]);

  if (supportCount >= requiredCount) {
    const nextStage = await getNextStage("SUPPORT_COLLECTION");
    if (nextStage) {
      await prisma.bookRequest.update({
        where: { id: bookRequestId },
        data: { status: nextStage.key, currentStageKey: nextStage.key },
      });
      await recordAudit({
        bookRequestId,
        action: "SUPPORT_THRESHOLD_MET",
        metadata: { supportCount, requiredCount },
      });
      if (nextStage.requiredRole) {
        await notifyUsersWithRole(
          nextStage.requiredRole.key,
          `${nextStage.requiredRole.label} review required for request (support threshold met).`,
          bookRequestId
        );
      }
    }
  }

  return { supportCount, requiredCount };
}

export async function removeSupport(bookRequestId: string, actor: AuthUser) {
  const existing = await prisma.support.findUnique({
    where: { bookRequestId_userId: { bookRequestId, userId: actor.id } },
  });
  if (!existing) throw new ApiError(404, "You have not supported this request.");
  await prisma.support.delete({ where: { id: existing.id } });
  await recordAudit({ bookRequestId, userId: actor.id, roleKeyAtTime: actor.roles[0], action: "SUPPORT_REMOVED" });
}

type Decision = "APPROVE" | "REJECT" | "RETURN";

/**
 * The central authorization + state-transition check for review stages.
 * A request purporting to approve/reject MUST currently be at a stage whose
 * requiredRole matches one of the actor's roles — this cannot be bypassed by
 * the frontend sending an arbitrary status.
 */
export async function decide(
  bookRequestId: string,
  actor: AuthUser,
  decision: Decision,
  comment?: string
) {
  const request = await prisma.bookRequest.findUnique({
    where: { id: bookRequestId },
    include: { requestedBy: { select: { department: true } } },
  });
  if (!request) throw new ApiError(404, "Request not found.");
  if (request.status === "CANCELLED") {
    throw new ApiError(409, "This request was cancelled by the requester and can no longer be acted on.");
  }

  const currentStage = await getStageByKey(request.status);
  if (!currentStage.requiredRole) {
    throw new ApiError(409, `Request is at "${currentStage.label}" — no approval action applies here.`);
  }
  if (["LIBRARIAN_VERIFICATION", "PROCUREMENT"].includes(currentStage.key)) {
    throw new ApiError(
      409,
      `"${currentStage.label}" uses its own dedicated action (librarian-verify / procurement endpoints), not a generic approve/reject decision.`
    );
  }
  const canAct = actor.roles.includes(currentStage.requiredRole.key);
  if (!canAct) {
    throw new ApiError(
      403,
      `Forbidden: this request is awaiting ${currentStage.requiredRole.label}, not your role.`
    );
  }
  // Every department has its own HOD — a Civil HOD should not approve a CSE
  // student's request and vice versa. Only enforced when both the requester
  // and the acting HOD have a department on file (older/demo accounts may not).
  if (currentStage.key === "HOD_REVIEW" && request.requestedBy.department && actor.department) {
    if (request.requestedBy.department !== actor.department) {
      throw new ApiError(
        403,
        `Forbidden: this request is from the ${request.requestedBy.department} department — only that department's HOD can act on it.`
      );
    }
  }

  await prisma.approval.create({
    data: {
      bookRequestId,
      stageKey: currentStage.key,
      actorId: actor.id,
      roleKeyAtTime: currentStage.requiredRole.key,
      decision,
      comment,
    },
  });

  let nextStatus: string;
  if (decision === "REJECT") {
    nextStatus = "REJECTED";
  } else if (decision === "RETURN") {
    nextStatus = "RETURNED_FOR_CORRECTION";
  } else {
    const next = await getNextStage(currentStage.key);
    if (!next) throw new ApiError(500, "Workflow misconfiguration: no next stage after final review.");
    nextStatus = next.key;
  }

  await prisma.bookRequest.update({
    where: { id: bookRequestId },
    data: { status: nextStatus, currentStageKey: nextStatus },
  });

  await recordAudit({
    bookRequestId,
    userId: actor.id,
    roleKeyAtTime: currentStage.requiredRole.key,
    action:
      decision === "APPROVE" ? "APPROVED" : decision === "REJECT" ? "REJECTED" : "RETURNED_FOR_CORRECTION",
    metadata: { fromStage: currentStage.key, toStage: nextStatus, comment },
  });

  await notifyUser(
    request.requestedById,
    `Your request ${request.displayId} was ${decision.toLowerCase()}d at the ${currentStage.label} stage.`,
    bookRequestId
  );

  if (decision === "APPROVE") {
    const nextStage = await getStageByKey(nextStatus);
    if (nextStage.requiredRole) {
      await notifyUsersWithRole(
        nextStage.requiredRole.key,
        `${nextStage.requiredRole.label} action required for ${request.displayId}.`,
        bookRequestId
      );
    }
  }

  return prisma.bookRequest.findUnique({ where: { id: bookRequestId } });
}

/**
 * Librarian action at LIBRARIAN_VERIFICATION: if the book is already available
 * in the library, no procurement is needed and the request completes here.
 * Otherwise it proceeds to PROCUREMENT.
 */
export async function librarianVerify(
  bookRequestId: string,
  actor: AuthUser,
  availableInLibrary: boolean,
  comment?: string
) {
  const request = await prisma.bookRequest.findUnique({ where: { id: bookRequestId } });
  if (!request) throw new ApiError(404, "Request not found.");
  if (request.status !== "LIBRARIAN_VERIFICATION") {
    throw new ApiError(409, "Request is not currently awaiting librarian verification.");
  }
  if (!actor.roles.includes("LIBRARIAN")) {
    throw new ApiError(403, "Forbidden: only a librarian may perform this action.");
  }

  await prisma.procurementRecord.upsert({
    where: { bookRequestId },
    update: { availableInLibrary },
    create: { bookRequestId, availableInLibrary },
  });

  const nextStatus = availableInLibrary ? "COMPLETED" : "PROCUREMENT";

  await prisma.bookRequest.update({
    where: { id: bookRequestId },
    data: { status: nextStatus, currentStageKey: nextStatus },
  });

  await recordAudit({
    bookRequestId,
    userId: actor.id,
    roleKeyAtTime: "LIBRARIAN",
    action: availableInLibrary ? "LIBRARIAN_CONFIRMED_AVAILABLE" : "LIBRARIAN_SENT_TO_PROCUREMENT",
    metadata: { comment },
  });

  await notifyUser(
    request.requestedById,
    availableInLibrary
      ? `Good news — ${request.displayId} is already available in the library.`
      : `${request.displayId} has been sent for procurement.`,
    bookRequestId
  );

  if (!availableInLibrary) {
    await notifyUsersWithRole("PROCUREMENT_ADMIN", `Procurement action required for ${request.displayId}.`, bookRequestId);
  }

  return prisma.bookRequest.findUnique({ where: { id: bookRequestId } });
}

const TERMINAL_STATUSES = ["COMPLETED", "REJECTED", "CANCELLED"];

/**
 * The requester can cancel their own request at any point before it's
 * finished, but must give a reason — reviewers/HOD/Principal may already
 * have spent time on it, so the reason is recorded in the audit trail and
 * shown to whoever was reviewing it.
 */
export async function cancelRequest(bookRequestId: string, actor: AuthUser, reason: string) {
  const request = await prisma.bookRequest.findUnique({ where: { id: bookRequestId } });
  if (!request) throw new ApiError(404, "Request not found.");
  if (request.requestedById !== actor.id) {
    throw new ApiError(403, "Only the requester can cancel this request.");
  }
  if (TERMINAL_STATUSES.includes(request.status)) {
    throw new ApiError(409, `Cannot cancel a request that is already ${request.status.toLowerCase()}.`);
  }

  const stageAtCancellation = request.status;
  const updated = await prisma.bookRequest.update({
    where: { id: bookRequestId },
    data: { status: "CANCELLED", currentStageKey: "CANCELLED", cancelledAt: new Date(), cancelReason: reason },
  });

  await recordAudit({
    bookRequestId,
    userId: actor.id,
    roleKeyAtTime: actor.roles[0],
    action: "CANCELLED",
    metadata: { stageAtCancellation, reason },
  });

  // Let whoever currently held the ball know, so a HOD/Principal who was
  // about to review it doesn't waste time on a withdrawn request.
  const stage = await prisma.workflowStage.findUnique({ where: { key: stageAtCancellation }, include: { requiredRole: true } });
  if (stage?.requiredRole) {
    await notifyUsersWithRole(
      stage.requiredRole.key,
      `${request.displayId} was cancelled by the requester at the ${stage.label} stage. Reason: ${reason}`,
      bookRequestId
    );
  }

  return updated;
}

/**
 * Soft-clears a finished request from the active list without deleting the
 * audit trail — the panel stops feeling cluttered while nothing is lost.
 * Only requests already at a terminal status can be archived.
 */
export async function archiveRequest(bookRequestId: string, actor: AuthUser) {
  const request = await prisma.bookRequest.findUnique({ where: { id: bookRequestId } });
  if (!request) throw new ApiError(404, "Request not found.");
  if (!TERMINAL_STATUSES.includes(request.status)) {
    throw new ApiError(409, "Only completed, rejected, or cancelled requests can be cleared from history.");
  }
  const updated = await prisma.bookRequest.update({
    where: { id: bookRequestId },
    data: { archivedAt: new Date() },
  });
  await recordAudit({ bookRequestId, userId: actor.id, roleKeyAtTime: actor.roles[0], action: "ARCHIVED" });
  return updated;
}

/** Marks a procurement-stage request as fully completed once accessioned. */
export async function completeAfterAccession(bookRequestId: string) {
  await prisma.bookRequest.update({
    where: { id: bookRequestId },
    data: { status: "COMPLETED", currentStageKey: "COMPLETED" },
  });
  await recordAudit({ bookRequestId, action: "COMPLETED" });
}

/** Builds the timeline view: every configured stage plus its status for this request. */
export async function buildTimeline(bookRequestId: string) {
  const [stages, request, approvals, supportCount, requiredSupportCount] = await Promise.all([
    getOrderedStages(),
    prisma.bookRequest.findUnique({ where: { id: bookRequestId } }),
    prisma.approval.findMany({ where: { bookRequestId }, include: { actor: true }, orderBy: { createdAt: "asc" } }),
    prisma.support.count({ where: { bookRequestId } }),
    getRequiredSupportCount(),
  ]);
  if (!request) throw new ApiError(404, "Request not found.");

  const mainStages = stages.filter((s) => s.key !== "RETURNED_FOR_CORRECTION" && s.key !== "REJECTED");

  // For terminal/returned statuses, the request's own status isn't one of the
  // "main" stages, so anchor progress on the stage where that decision was
  // made (the most recent approval) instead of showing everything as locked.
  const isHalted = ["REJECTED", "RETURNED_FOR_CORRECTION", "CANCELLED"].includes(request.status);
  const haltingApproval = isHalted ? approvals[approvals.length - 1] : undefined;
  const anchorKey = isHalted ? haltingApproval?.stageKey : request.status;
  const currentOrder = mainStages.find((s) => s.key === anchorKey)?.order ?? -1;

  return mainStages.map((stage) => {
    const approval = approvals.find((a) => a.stageKey === stage.key);
    let uiStatus: "done" | "current" | "locked" | "skipped" = "locked";
    if (isHalted) {
      if (stage.order < currentOrder) uiStatus = "done";
      else if (stage.order === currentOrder) uiStatus = "current"; // decision (reject/return) shown via `approval` field
    } else if (stage.order < currentOrder) uiStatus = "done";
    else if (stage.order === currentOrder) uiStatus = "current";

    return {
      key: stage.key,
      label: stage.label,
      order: stage.order,
      requiredRole: stage.requiredRole?.key ?? null,
      uiStatus,
      support: stage.key === "SUPPORT_COLLECTION" ? { count: supportCount, required: requiredSupportCount } : undefined,
      approval: approval
        ? { decision: approval.decision, actor: approval.actor.fullName, comment: approval.comment, at: approval.createdAt }
        : undefined,
    };
  });
}
