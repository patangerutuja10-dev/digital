import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { ApiClientError } from "../api/client";

const DEMO_ACCOUNTS = [
  ["demo.student@college.edu", "Student"],
  ["demo.student2@college.edu", "Student (2nd, for testing Support)"],
  ["demo.faculty@college.edu", "Faculty"],
  ["demo.incharge@college.edu", "Subject In-charge"],
  ["demo.hod@college.edu", "HOD"],
  ["demo.principal@college.edu", "Principal"],
  ["demo.librarian@college.edu", "Librarian"],
  ["demo.procurement@college.edu", "Procurement"],
  ["demo.admin@college.edu", "Admin"],
];

export default function Login() {
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("demo.student@college.edu");
  const [password, setPassword] = useState("Demo@123");
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Login failed.");
    }
  }

  return (
    <div className="login-wrap">
      <div className="login-brand">
        <img className="login-banner" src="/college-banner.jpg" alt="P. R. Pote Patil College of Engineering & Management, Amravati" />
      </div>
      <form className="login-card" onSubmit={handleSubmit}>
        <h1>Digital Library Workflow</h1>
        <p className="subtitle">Book Recommendation &amp; Procurement System</p>

        {error && <div className="alert alert-error">{error}</div>}

        <div className="form-field">
          <label>Email</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
        </div>
        <div className="form-field">
          <label>Password</label>
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
        </div>
        <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: "100%" }}>
          {loading ? "Signing in..." : "Sign in"}
        </button>

        <div className="demo-box">
          <strong>Demo accounts</strong> (password for all: <code>Demo@123</code>) &mdash; clearly labeled
          seed data, not real college accounts:
          <ul style={{ margin: "8px 0 0 0", paddingLeft: 18 }}>
            {DEMO_ACCOUNTS.map(([mail, role]) => (
              <li key={mail}>
                <button
                  type="button"
                  className="link"
                  style={{ background: "none", border: "none", padding: 0, cursor: "pointer", color: "#1d4e89", textDecoration: "underline" }}
                  onClick={() => setEmail(mail)}
                >
                  {mail}
                </button>{" "}
                — {role}
              </li>
            ))}
          </ul>
        </div>
      </form>
    </div>
  );
}
